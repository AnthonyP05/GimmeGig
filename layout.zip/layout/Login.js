// pages/index.js
import ImagePanel from '../components/LoginComponents/ImagePanel'
import RightPanel from '../components/LoginComponents/RightPanel'

export default function HomePage() {
  // Inline style objects
  const containerStyle = {
    display: 'flex',
    flex: 1,
    height: '100vh',
    margin: 0,
    padding: 0,
    width: '100vw', // Ensure it takes the full width of the viewport
    overflow: 'hidden', // Prevent horizontal scrolling
  }

  return (
    <div style={containerStyle}>
      <ImagePanel />
      <RightPanel />
    </div>
  )
}