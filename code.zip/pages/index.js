import Layout from '../components/Layout';
import Homepage from './loginpage';

export default function Home() {
  return (
    <Layout>
      <Homepage />
    </Layout>
  );
}
