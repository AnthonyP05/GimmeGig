import Image from 'next/image'

export default function ImagePanel() {

    const leftPaneStyle = {
        position: 'relative',
        width: '50%',
        height: '100vh',
        overflow: 'hidden',
      }
    
      const imageStyle = {
        // next/image handles most sizing, but we still do absolute fill:
        objectFit: 'cover',
      }
    
      const overlayStyle = {
        position: 'absolute',
        top: 0,
        right: 0,
        bottom: 0,
        left: 0,
        backgroundColor: 'black',
        opacity: 0.3,
      }
    
      const brandStyle = {
        position: 'absolute',
        top: '1rem',
        left: '1rem',
        color: '#fff',
        fontSize: '1.5rem',
        fontWeight: 'bold',
        zIndex: 2, // ensure it stays above the overlay
      }

    return (
        <div style={leftPaneStyle}>
            <div style={brandStyle}>GimmeGig</div>
            <Image
            src="/stage.jpeg"
            alt="Musician on stage"
            fill    // fill the container
            style={imageStyle}
            priority
            />
            <div style={overlayStyle}></div>
      </div>
    )
  }