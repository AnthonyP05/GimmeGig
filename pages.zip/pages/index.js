import Homepage from '../layout/Login';

export default function Home() {
  return (
    <div>
      <Homepage />
    </div>
  );
}