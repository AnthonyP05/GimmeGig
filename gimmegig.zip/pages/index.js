import Homepage from './loginpage';

export default function Home() {
  return (
    <div>
      <Homepage />
    </div>
  );
}